# Отчет по лабораторной работе 
## по курсу "Искусственый интеллект"

## Нейросетям для распознавания изображений


### Студенты: 

| ФИО       | Роль в проекте                     | Оценка       |
|-----------|------------------------------------|--------------|
| Семенов Д.В. | Обучил нейросети,составил датасет |  Молодец        |
| Поскряков Я.С. | Обучил нейросети |  Тоже Молодец     |
| Ветренко П.С.| Написание отчёта,мотиватор | Супер Молодец     |

## Результат проверки

| Преподаватель     | Дата         |  Оценка       |
|-------------------|--------------|---------------|
| Сошников Д.В. |     28.05.2020         |    4.8           |

> *Здорово, что реализовали сети на Pytorch + Tensorflow. Стоило бы подробнее рассмотреть вопрос пере- или недо-обучения, а также попытаться побороться с осцилляциями точности - за счет снижения learning rate или перемешивания обучающих данных.*

## Тема работы

Построение нейронных сетей для классификации рукописных символов, галочки и крестика.

## Распределение работы в команде

Все в команде занимались аккуратным и качественным написанием символов.Семенов Денис занимался созданием датасета,изменением кантрастности и яркости фото,выравниваем и т.д. Также Денис и Ярослав занимались обучением нейросетей-Ярослав на Keras,а Денис на Pytorch.Полина занималась красивым и грамотным написанием отчетом. 

## Подготовка данных

Изображение галочки без какой-либо обработки:

<img src="https://github.com/MAILabs-Edu-AI/lab-neural-networks-vision-nn/blob/master/photo/semenov_v.jpg" width="250">

Откорректированное изображение галочки:

<img src="https://github.com/MAILabs-Edu-AI/lab-neural-networks-vision-nn/blob/master/photo/semenov_v_crop.jpg" width="250">

Пример изображения галочки:

![](all_photo/v/imv_p_0_0.jpg)

Написание аккуратных и ровных символом было с помощью разлинованной таблицы.Но не смотря на это не все символы были ровные и отцентрованные,пришлось выравнивать и убирать артефакты.

```

for i in range(10):
    for j in range(10):
        x = imx[i*124:(i+1)*124,(j)*123:(j+1)*123]
        x = cv.resize(x, (32,32))
        x = cv.cvtColor(x, cv.COLOR_RGB2GRAY)
        #plt.imshow(x)
        #plt.pause(0.0001)
        
        cv.imwrite('imx_{}_{}.jpg'.format(i,j), x)
        
```

Ссылка на получившийся датасет:

https://github.com/MAILabs-Edu-AI/lab-neural-networks-vision-nn/tree/master/all_photo

## Загрузка данных

Загрузка данных в Pytorch:
```
loader = DataLoader(
      torchvision.datasets.ImageFolder('../all_photo/', 
                                 transform=torchvision.transforms.Compose([
                                   torchvision.transforms.ToTensor(),
                                   torchvision.transforms.Normalize(
                                   [0.5,0.5,0.5],[0.5,0.5,0.5])  
                                 ])), batch_size=1, shuffle=True)

```

Загрузка данных в Keras:
```
img_size = (32,32)
batch_size = 30

data_gen = keras.preprocessing.image.ImageDataGenerator(rescale=1./255.)
data_gen_aug = keras.preprocessing.image.ImageDataGenerator(rescale=1./255., rotation_range=5, horizontal_flip=True, zoom_range=0.2)

train_flow = data_gen_aug.flow_from_directory('train_2people_train_1test/train',target_size=img_size,batch_size=batch_size,class_mode='categorical', shuffle = True)
valid_flow = data_gen.flow_from_directory('test_2people_train_1test/test',target_size=img_size,batch_size=batch_size,class_mode='categorical', shuffle = False)
```

## Обучение нейросети

### Полносвязная однослойная сеть
**Архитектура**

В Pytorch:
```
class Net1(nn.Module):
    def __init__(self):
        super(Net1, self).__init__()
        self.fc1 = nn.Linear(32*32, 1)
    def forward(self, x):
        x = self.fc1(x)
        return F.sigmoid(x)
```
![](https://github.com/MAILabs-Edu-AI/lab-neural-networks-vision-nn/blob/master/photo/2020-05-11%2022.15.37.jpg)
На верхнем графике значение loss-функции на train выборке,а на нижнем синее-accuracy на validation,желтое-loss на validation.
Количество эпох - 15.
Параметров - 1025.

В Keras:

```
model = keras.Sequential([
    keras.layers.Flatten(input_shape = img_size+(3,)),
    keras.layers.Dense(2, activation='softmax')
])
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
model.summary()
```
![](https://github.com/MAILabs-Edu-AI/lab-neural-networks-vision-nn/blob/master/photo/2020-05-11%2022.17.33.jpg)
Красное-accuracy на validation выборке, синее-accuracy на train выборке.
Количество эпох - 25.
Параметров - 258.

### Полносвязная многослойная сеть
**Архитектура**

В Pytorch:
```
class Net2(nn.Module):
    def __init__(self):
        super(Net2, self).__init__()
        self.fc1 = nn.Linear(32 * 32, 20)
        self.fc2 = nn.Linear(20, 20)
        self.fc3 = nn.Linear(20, 1)
    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return F.sigmoid(x)
```
Параметров - 245 401.
Эпох - 15.
![](https://github.com/MAILabs-Edu-AI/lab-neural-networks-vision-nn/blob/master/photo/2020-05-11%2022.43.02.jpg)

В Keras:
```
model = keras.Sequential([
    keras.layers.Flatten(input_shape = img_size+(3,)),
    keras.layers.Dense(128, activation='relu'),
    keras.layers.Dense(2, activation='softmax')
])
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
model.summary()
```
Параметров - 393 602.
![](https://github.com/MAILabs-Edu-AI/lab-neural-networks-vision-nn/blob/master/photo/2020-05-11%2022.45.45.jpg)

### Свёрточная сеть
**Архитектура** 

В Pytorch:

```
class Net5(nn.Module):
    def __init__(self):
        super(Net5, self).__init__()
        self.conv1 = nn.Conv2d(3, 3, 5)
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(3, 6, 5)
        self.fc1 = nn.Linear(6 * 5 * 5, 70)
        self.fc2 = nn.Linear(70, 10)
        self.fc3 = nn.Linear(10, 1)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = x.view(1, 6 * 5 * 5)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return F.sigmoid(x)
```
Параметров - 16 897.
Эпох - 5.
![](https://github.com/MAILabs-Edu-AI/lab-neural-networks-vision-nn/blob/master/photo/2020-05-11%2022.43.07.jpg)

В Keras:

```
model = Sequential()
model.add(Conv2D(32, (3, 3), input_shape = img_size+(3,), activation='relu'))
model.add(Conv2D(32, (3, 3), activation='relu'))
model.add(MaxPool2D(pool_size=(2, 2)))
model.add(Conv2D(64,(3,3),activation='relu'))
model.add(MaxPooling2D())
model.add(Flatten())
model.add(Dropout(0.25))
model.add(Dense(units=2, activation='softmax'))
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
model.summary()
```
Параметров - 33 250.

![](https://github.com/MAILabs-Edu-AI/lab-neural-networks-vision-nn/blob/master/photo/2020-05-11%2022.36.42.jpg)

## Выводы

Эта лабораторная работа была очень полезной,т.к. связана непосредственно с нашей деятельностью.В процессе выполнения лабораторной работы мы познакомились с различными видами нейронных сетей и разобрались,как с ним работать.Нейронные сети-это мощное средство в умелых руках.Очень важно понимать поэтапную работу алгоритма.

Сложность состояла в ручной обработке фотографий, а также в их недостатке,т.к. обычно нейронным сетям требуется больший набор данных.Также одной из сложностей является то,что форум по Pytorch не открывался,поэтому пришлось искать информацию на других сайтах.

Командная работа была успешной,не возникало каких-либо разногласий и сложностей в работе.

Однослойная нейронная сеть показала себя неплохо,т.к. фотографии выравнены и тщательно обработаны,поэтому задействовались одни и те же нейроны.Сверточная нейронная сеть показала себя лучше лучше многослойной,т.к. в ней намного меньше параметров,но при этом она сохраняет обобщающую способность.
